SCPDiscordBotOnline
---------------------

Это бот для показа количества игроков на сервере игры SCP:SL!

Функционал
---------------------

Показ количества игроков в статусе бота
![alt-текст](https://github.com/adam-p/markdown-here/raw/master/src/common/images/icon48.png)